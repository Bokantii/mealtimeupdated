import { View, Text } from 'react-native'
import React from 'react'

const SelectCollections = () => {
  return (
    <View>
      <Text>SelectCollections</Text>
    </View>
  )
}

export default SelectCollections;