import React from 'react'
import { View,Text } from 'react-native'
const Groceries = () => {
  return (
    <View>
      <Text>Welcome to Groceries Screen!!!</Text>
    </View>
  )
}

export default Groceries
