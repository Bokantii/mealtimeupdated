import React from 'react'
import { View,Text } from 'react-native'
const Settings = () => {
  return (
    <View>
      <Text>Welcome to Settings Screen!!</Text>
    </View>
  )
}

export default Settings
