class Ingredient{
    constructor(id,quantityId){
        this.id=id
        this.quantityId=quantityId
    }
}
export default Ingredient;