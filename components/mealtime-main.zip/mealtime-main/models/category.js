class Category{
  constructor(id,title){
    this.id=id,
    this.title=title
  }
}

export default Category;