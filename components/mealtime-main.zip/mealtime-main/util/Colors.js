export const Colors = {
  bodybgColor: "#FFFAF5",
  bgDark:"#2e1a03",
  inputBgColor:"#fff",
  mealTimePrimary:'#F58700',
  inputBorderColor:"#CCCCCC",
  flatBtnColor:"#3E3E3D",

  error100: "#fcdcbf",
  error500: "#f37c13",
  unfocused:"#bdbdbd"
};
